function deleteitem(){
    let li = $(ev.currentTarget).parents(".item"),
      itemId = li.attr("data-item-id");
      console.log(itemID);
}