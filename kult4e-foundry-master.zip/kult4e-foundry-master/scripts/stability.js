function stability(){
    let i = data.stability.value;
    console.log(i);

}